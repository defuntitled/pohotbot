function pay(){
	
		alert("THANKS FOR YOUR DONATION");
		}
	
