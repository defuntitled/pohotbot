from tkinter import *
from wot_game_gachi_of import *
from random import choice
ns=['Dungeon_master','Fucking_slave','Boss_of_gym','Leatherman','Boy_next_door','Billy']
def pay():
	global entt1,entt2,entt3,winpay
	a=entt1.get()
	b=entt2.get()
	c=entt3.get()
	if a == '1337-1337-1337-1377' and b == '228' and c == '69/69':
		with open('config.gachi','w') as f:
			f.write("payed")
		winpay.destroy()
		truenick=choice(ns)
		ingachi(truenick)
	else:
		with open('config.gachi','w') as f:
			f.write("fuck you")
def inasspay():
	global entt1,entt2,entt3,winpay,truenick
	winpay=Tk()
	winpay.title('Оплата 300$ в процессе')
	winpay.geometry('450x400') 
	pole=Canvas(winpay, height=450, width=200, bg="white")	
	lab1=Label(winpay,text=(chr(9794) + ' МАГАЗИН ВОЕННЫХ ТАНКОВ ' + chr(9794)),width=34,font='arial 22',bg='magenta',fg='black')
	lab2=Label(winpay,text='Нумер карты:',width=20,font='arial 10',bg='gray',fg='magenta')
	lab3=Label(winpay,text='CVV:',width=10,font='arial 16',bg='gray',fg='magenta')
	lab4=Label(winpay,text='Дата действия:',width=24,font='arial 10',bg='gray',fg='magenta')
	entt1=Entry(winpay,width=25,font='arial 10',bg='white',fg='magenta')
	entt2=Entry(winpay,width=20,font='arial 10',bg='white',fg='magenta')
	entt3=Entry(winpay,width=20,font='arial 10',bg='white',fg='magenta')
	butt1=Button(winpay,text=(chr(9794) + ' ОПЛАТИТЬ ' + chr(9794)),width=22,font='arial 24',bg='gray',fg='black',command=pay)
	lab1.place(x=50,y=10)
	lab2.place(x=20,y=45)
	lab3.place(x=20,y=145)
	lab4.place(x=240,y=45)
	entt1.place(x=20,y=60)
	entt2.place(x=20,y=160)
	entt3.place(x=240,y=60)
	butt1.place(x=150,y=145)
	winpay.mainloop()

	
