from PIL  import Image,ImageTk   # readimage.py  в папке plata
def readimg(nameimg):  # массив  имен файлов изображений
	n=len(nameimg)
	imgmas=[]
	for i in range(n):
		name=nameimg[i]
		img=Image.open(name)
		photo=ImageTk.PhotoImage(img)
		imgmas.append(photo)
	return imgmas  # на выходе изображения для Canvas
