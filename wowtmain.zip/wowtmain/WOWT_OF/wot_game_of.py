from tkinter import *
from random import choice
import time
ms=['Броня побрита','Броня пробита','Броня пробита','Броня пробита','Броня пробита','Броня прибита','Рикошет','Рикошет','Рикошет','Рикардшрек','Наводчик контужен','Механик контужен','Автор отравлен','Жопа разорвана','танк уничтожен']
ty=['Молодец, тимофей','Отлично, Тимофей','Тимофей 5','Тимофей 6!','Тимофей 7!!!','Тимофей 6!','Тимофей 5','Тимофей 5','Тимофей 5','Молодец Тимофей','Отлично Тимофей','Тимофей, nice cock']
cp=['УБЕРИ СОТОВЫЙ','УБЕРИ СОТОВЫЙ!!!!','УБЕРИ!']
bs=['Раздаем листочки','Ведем практческую','Ведем практческую','Ведем практческую','Ведем практческую']
import sys
dch=0
pr=0
p=0
asshits=0
td=0
sd=0
ANAL=0
ip=0
s='			 ТАААААААААААНКДУЛООООООООО 8===>'
r='		        ТАААААААААААНКДУЛООООООООО   '
tr='		ТАААААААААААНКДУЛООООООООООООООООООО  '
ts='		          ТАААААААААААНКДУЛООООООООООООООООООО 8===>'
ybor=0
def SOTOV():
	global lab11,lab12,lab13,pr,lab18,lab20,lab14,sd
	if pr==1:
		lab11.config(text='I                                                                                                                                               I')
		lab12.config(text='I                                                                                                                                               I')
		lab13.place(x=5,y=430)
		pr=0
	else:
		if ybor==1:
			s='СОТОВЫЙ!!!'
			ybor=0
		else:
			s=choice(cp)
		if s=='УБЕРИ!':
			ybor=1
		lab18.config(text='УЖЕ ПРОВЕРЯЕМ')
		sd+=1
		lab20.config(text=sd)
		lab14.config(text=s)
def SIT():
	global lab11,lab12,lab14,lab13,pr,lab18,td,lab17
	if pr==0:
		lab11.config(text='')
		lab12.config(text='')
		lab13.place(x=5,y=370)
		pr=1
	else:
		s=choice(ty)
		lab18.config(text='УЖЕ ИГРАЕМ В САПЕРА')
		td+=1
		lab17.config(text=td)
		lab14.config(text=s)
def keypressed(event):
	k=event.keycode
	if k==113:
		FIRE()
	if k==114:
		RELOAD()
def FIRE():
	global p, lab4,lab14, lab17,lab18,asshits,td,sd,lab20,ANAL,ip,truenick,dch
	if p==0:
		if asshits==4:
			if truenick == 'timofeieschyintima' or truenick == 'ivannavi' or truenick == 'egorka':
				lab4.config(text=ts)
			else:
				lab4.config(text=s)
			lab14.config(text='союзник уничтожен')
			if truenick == 'boginya':
				lab14.config(text='практическая проведена',width=40)
			asshits=0
			td+=1
			p=1
		else:
			if truenick == 'timofeieschyintima' or truenick == 'ivannavi' or truenick == 'egorka':
				lab4.config(text=ts)
			else:
				lab4.config(text=s)
			if truenick == 'boginya':
				f=choice(bs)
			elif dch==1:
				f='Пост сделан'
			else:
				f=choice(ms)
			lab14.config(text=f)
			p=1
			if (f!='Рикошет') or (f!='Рикардшрек') or f!='Раздаем листочки':
				asshits+=1
			if f=='Раздаем листочки':
				asshits+=1
			if f=='Пост сделан':
				asshits=0
				td+=1
			if f=='танк уничтожен': 
				asshits=0
				td+=1
		lab18.config(text='ТРЕБУЕТСЯ ПЕРЕЗАРЯДКА')
		if dch==1:
			lab18.config(text='Нужен прикол')
		if truenick == 'boginya':
			lab18.config(text='5 МИНУТ ДО КОНЦА УРОКА')
	else:
		lab14.config(text='танк уничтожен')
		if truenick == 'boginya':
			lab14.config(text='тимофея забуллили')
		if dch==1:
			lab14.config(text='Пост сделан')
		sd+=1
	lab17.config(text=td)
	lab20.config(text=sd)
	if ip==1:
		RELOAD()
	if sd==5:
		ANAL=1
		FAIL()
def RELOAD():
	global p, lab4,lab14,lab18,butt2,ip,truenick,dch
	if ip!=1:
		if truenick == 'timofeieschyintima' or truenick == 'ivannavi' or truenick == 'egorka':
			lab4.config(text=tr)
		else:
			lab4.config(text=r)
		lab14.config(text='')
		lab18.config(text='ПЕРЕЗАРЯДКА!!!!!')
		if dch==1:
			lab18.config(text='404 листаеца')
		if truenick == 'boginya':
			lab18.config(text='ЖДЕМ ЗВОНОК!!!!')
		butt2.config(command='')
		if dch!=1:
			root.after(5000,actualreload)
	else:
		p=0
		lab18.config(text='ДУЛО ГОТОВО!!!')
def actualreload():
	global p,butt2,truenick,dch
	if dch!=1:
		butt2.config(command=RELOAD)
	lab18.config(text='ДУЛО ГОТОВО!!!')
	if truenick == 'boginya':
		lab18.config(text='ДОСТАВАЙТЕ ДВОЙНЫЕ ЛИСТОЧКИ!!!')
	if dch==1:
		lab18.config(text='всё хуйня, переделывай')
	if dch != 1:
		p=0
def FAIL():
	global root,ANAL,truenick,dch
	root.destroy()
	root=Tk()
	if truenick == 'rybytskayvalentina' or truenick == 'boginya':
		root.title('Ошибка подключения')
	elif dch==1:
		root.title('Дети 404')
	else:
		if ANAL==0:
			root.title('вы сдались')
		else:
			root.title('вы кикнуты за уничтожение врагов')
	root.geometry('800x600')
	butt1=Button(root,text='ТЫ ПИДОРАС!!!!',width=50,height=20,font='arial 30',bg='magenta',fg='yellow',command=ass)
	if truenick == 'rybytskayvalentina' or truenick == 'boginya':
		butt1.config(text='Всем 2')
	if dch==1:
		butt1.config(text='ВЫ ЗАБАНЕНЫ!!!!')
	butt1.place(x=0,y=0)
	root.after(10000,ass)
	root.mainloop()
def ass():
	sys.exit()
def inass(nick):
	global lab4,lab11,lab12,lab13,lab14, entt1, lab17,lab18,butt2,lab20,truenick,dch,ip
	if nick == 'ivannavi' or nick == 'timofeieschyintima' or nick == 'egorka' or nick == 'boginya' or nick == 'ded' or nick == 'rybytskayvalentina' or nick == 'svyatoslavpeskov' or nick == 'artekklinski' or nick == 'kiryabachlichkeev' or nick == 'pankozloski' or nick == 'eltsin' or nick == 'dilibeevbilichukin' or nick == 'ChoCh':       
		global root
		truenick=nick
		if nick == 'ivannavi' or truenick == 'egorka':
			ip=1
		if nick == 'kiryabachlichkeev' or nick == 'pankozloski' or nick == 'eltsin' or nick == 'dilibeevbilichukin' or nick == 'ChoCh':
			dch=1
		root=Tk()	
		root.title(chr(9794) + ' ' + 'долбежка в ass'+ ' ' + chr(9794))
		root.geometry('1200x600')
		pole=Canvas(root,width=1200,height=600,bg='yellow')
		pole.place(x=0,y=00)
		lab1=Label(root,text='ТААААААААААНК',width=80,font='arial 22',bg='yellow',fg='black')
		lab2=Label(root,text='ТААААААААААААНК',width=80,font='arial 22',bg='yellow',fg='black')
		lab3=Label(root,text='ТААААААААААААНК',width=80,font='arial 22',bg='yellow',fg='black')
		lab4=Label(root,text=r,width=80,font='arial 22',bg='yellow',fg='black')
		if nick == 'timofeieschyintima' or nick == 'ivannavi' or nick == 'egorka':
			lab4.config(text=tr,width=100)
		lab6=Label(root,text='ТААААААААААААНК',width=80,font='arial 22',bg='yellow',fg='black')
		lab7=Label(root,text='__ТАААААААААААААААААААААААААААААААААНК__',width=80,font='arial 22',bg='yellow',fg='black')
		lab8=Label(root,text='ТААААААААААААААААААААААААНК',width=80,font='arial 22',bg='yellow',fg='black')
		lab9=Label(root,text='ТАААААААААААААААААААААААААААААААНК',width=80,font='arial 22',bg='yellow',fg='black')
		lab10=Label(root,text='I                                                                                                                                               I',width=80,font='arial 22',bg='yellow',fg='black')
		lab11=Label(root,text='I                                                                                                                                               I',width=80,font='arial 22',bg='yellow',fg='black')
		lab12=Label(root,text='I                                                                                                                                               I',width=80,font='arial 22',bg='yellow',fg='black')
		lab13=Label(root,text='\_________________________________________________________________/',width=80,font='arial 22',bg='yellow',fg='black')
		lab14=Label(root,text=' ',width=30,font='arial 16',bg='yellow',fg='magenta')
		lab15=Label(root,text=nick,width=20,font='arial 16',bg='gray',fg='magenta')	
		lab16=Label(root,text='Союзников уничтожено:',width=30,font='arial 12',bg='gray',fg='magenta')
		if nick == 'rybytskayvalentina':
			lab16.config(text='Тимофеев ублажено:')
		if nick == 'timofeieschyintima':
			lab16.config(text='Шестерок по шизике:')
		if nick == 'boginya':
			lab16.config(text='Практических проведено:',width=36)
		if dch==1:
			lab16.config(text='Based:')
		lab17=Label(root,text=td,width=3,font='arial 12',bg='gray',fg='magenta')
		lab18=Label(root,text='ДУЛО ГОТОВО!!!',width=30,font='arial 12',bg='gray',fg='magenta')
		if nick == 'rybytskayvalentina':
			lab18.config(text='ГЕМОРРОЙ НАСТУПАЕТ!!!')
		if nick == 'timofeieschyintima':
			lab18.config(text='ШИЗИКA ПО РАСПИСАНИЮ!!',width=32)
		if nick == 'boginya':
			lab18.config(text='ГЕОГРАФИЯ СЕДЬМЫМ!!!',width=40)
		if dch==1:
			lab18.config(text='4:19 НА ЧАСАХ!!!')
		lab19=Label(root,text='Врагов уничтожено:',width=30,font='arial 12',bg='gray',fg='magenta')
		if nick == 'rybytskayvalentina':
			lab19.config(text='Проверено конспектов:')
		if nick == 'boginya':
			lab19.config(text='Тимофей забуллен:')
		if nick == 'timofeieschyintima':
			lab19.config(text='Четверок по шизике:')
		if dch==1:
			lab19.config(text='Cringe:')
		lab20=Label(root,text=sd,width=3,font='arial 12',bg='gray',fg='magenta')
		lab1.place(x=5,y=100)
		lab2.place(x=5,y=130)
		lab3.place(x=5,y=160)
		lab4.place(x=5,y=190)
		lab6.place(x=5,y=220)
		lab7.place(x=5,y=310)
		lab8.place(x=5,y=250)
		lab9.place(x=5,y=280)
		lab10.place(x=5,y=340)
		lab11.place(x=5,y=370)
		lab12.place(x=5,y=400)
		lab13.place(x=5,y=430)
		lab14.place(x=100,y=50)
		lab15.place(x=850,y=30)
		lab16.place(x=100,y=30)
		lab17.place(x=335,y=30)
		lab18.place(x=750,y=500)
		lab19.place(x=100,y=10)
		lab20.place(x=335,y=10)
		butt1=Button(root,text='ОГОНЬ!!!!',width=15,font='arial 16',bg='red',fg='black',command=FIRE)
		if nick == 'rybytskayvalentina':
			butt1.config(text='Проверить сотовый',width=30,command=SOTOV)
		if nick == 'boginya':
			butt1.config(text='Раздать листочки',width=30)
		if dch==1:
			butt1.config(text='Запостить пост',width=32)
		butt2=Button(root,text='ЗАРЯЖАЙ!!!!',width=15,font='aria16',bg='gray',fg='black',command=RELOAD)
		if nick == 'rybytskayvalentina':
			butt2.config(text='Присесть',command=SIT)
			butt2.place(x=200,y=600)
		if nick == 'boginya':
			butt2.config(text='Закончить урок',width=24,command=RELOAD)
			butt2.place(x=200,y=600)
		if dch==1:
			butt2.config(text='Найти контент',width=24)
		butt3=Button(root,text='Сдаться',width=15,font='arial 16',bg='gray',fg='black',command=FAIL)
		if nick == 'rybytskayvalentina' or nick == 'boginya':
			butt3.config(text='Сетевой')
		if dch==1:
			butt3.config(text='Зайти в 404')
		butt1.place(x=20,y=500)
		butt2.place(x=200,y=500)
		if dch==1:
			butt2.place(x=300,y=500)
		butt3.place(x=500,y=500)
		if nick == 'boginya' or nick == 'rybytskayvalentina':
			butt2.place(x=300,y=500)
		root.bind('<Key>',keypressed)
		root.mainloop()
	else: sys.exit()	
